
readme: this file.

These are the artifacts for a developing RES4 token Dapp.

Listing9.1, RES4.sol
Smart contract defining the token RES4.



RES4-Dapp.zip
The files for RES4-contract and RES4-app of RES4 token.

Make a note of the the helper smart contracts in the directory RES4-contract/contracts/helper-contracts.

