
readme: this file.

These are the artifacts for a developing DCC Dapp.

Listing11.1, DCC.sol
Smart contract defining the DCC application.

Listing11.2, truffle-config.js
truffle-config.js specifying the configuration for local, public and test deployment of DCC smart contract.

DCC-Dapp-local.zip
The files for DCC-contract and DCC-app for prototyping and local deployment on Ganache.


DCC-Dapp-public.zip
The files for DCC-contract and DCC-app for public deployment on Infura and Ropsten. 

DCC-Dapp-app-only.zip
The files for DCC-app for distribution to decentralized participants to interaction with public deployment of DCC smart contract.